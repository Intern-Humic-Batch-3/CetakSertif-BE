CREATE TABLE `user`(
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `nama_depan` VARCHAR(255) NOT NULL,
    `nama_belakang` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `password` TEXT NOT NULL,
    `role` ENUM('admin', 'super admin') NOT NULL,
    `created_at` DATETIME NOT NULL
);
CREATE TABLE `foto_tamplate_sertifikat`(
    `id` BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `id_user` BIGINT NOT NULL,
    `img_path` TEXT NOT NULL COMMENT 'link ke firebase',
    `created_at` DATETIME NOT NULL
);
ALTER TABLE
    `foto_tamplate_sertifikat` ADD CONSTRAINT `foto_tamplate_sertifikat_id_user_foreign` FOREIGN KEY(`id_user`) REFERENCES `User`(`id`);